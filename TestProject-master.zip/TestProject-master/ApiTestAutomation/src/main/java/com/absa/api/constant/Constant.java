package com.absa.api.constant;

public class Constant {

	
	 //API Testing Constants
    public static final String API_PROPERTY_FILE_PATH = "F:\\Projects\\ApiTestAutomation\\src\\main\\java\\com\\absa\\api\\config\\Config.properties";
    public static final String RETIREVER = "retriever";

  //  F:\Projects\ApiTestAutomation\src\main\java\com\absa\api\config\Config.properties

    //Path To Save API Report

   // public static final String REPORT_PATH = System.getProperty("user.dir") + "//Reporting//Report//";

public static final String REPORT_PATH="F:\\Projects\\ApiTestAutomation\\Reporting\\Report";


    //Other Details
    public static final String IMAGE_1 = "Screen 1";
    public static final String IMAGE_2 = "Screen 2";
    public static final String IMAGE_3 = "Screen 3";
    public static final String IMAGE_4 = "Screen 4";

    public static final String REPORT_FILE_NAME_PATH = "./resources/ReportsConfig.xml";
    //F:\Projects\ApiTestAutomation\src\main\resources\ReportsConfig.xml

    public static final String TAKE_SCREEN_SHOT = "./screenShots/";
    
}
